// CSV data
const csvData = `
Gifted Braimah,Class 1,Joshua high school,maths,10,30,40,English language,20,50,70,Agriculture,30,70,100
SammyZachs,Class 2,Kennedy high school,Economics,20,50,70,Algebra,35,40,75,Social Science,40,60,100,Chemistry,30,55,85
`;

// Function to parse CSV
function parseCSV(data) {
  return data.trim().split("\n").map(row => {
    const [name, className, school, ...subjects] = row.split(",");
    let subjectDetails = [];
    for (let i = 0; i < subjects.length; i += 4) {
      subjectDetails.push({
        name: subjects[i],
        testScore: subjects[i + 1],
        midtermScore: subjects[i + 2],
        finalScore: subjects[i + 3]
      });
    }
    return { name, className, school, subjectDetails };
  });
}

// Render data into HTML
function renderReport(data) {
  const container = document.getElementById("report-container");
  data.forEach(student => {
    const studentDiv = document.createElement("div");
    studentDiv.classList.add("student");

    studentDiv.innerHTML = `
      <div class="student-name">Name: ${student.name}</div>
      <div class="class-name">Class: ${student.className}</div>
      <div class="school-name">School: ${student.school}</div>
      <table class="subject-table">
        <thead>
          <tr>
            <th>Subject</th>
            <th>Test Score</th>
            <th>Midterm Score</th>
            <th>Final Score</th>
          </tr>
        </thead>
        <tbody>
          ${student.subjectDetails.map(sub => `
            <tr>
              <td>${sub.name}</td>
              <td>${sub.testScore}</td>
              <td>${sub.midtermScore}</td>
              <td>${sub.finalScore}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
    container.appendChild(studentDiv);
  });
}

// Process and render
const students = parseCSV(csvData);
renderReport(students);
s