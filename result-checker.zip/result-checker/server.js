const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Endpoint to handle form submission
app.post('/submit', (req, res) => {
  const {
    session, term: schoolTerm, next_term, name, class: studentClass, student_id,
    attendance, days_absent, sex: studentSex, no_of_subjects, total_score,
    students_average, class_average, position_in_class, out_of, neatness,
    punctuality, sense_of_responsibility, teamwork, initiatiave, communication_skills,
    musical_skills, sports, craft, hardworking, teachers_remark, head_remark, subjects
  } = req.body;

  // Convert all fields to uppercase
  const row = [
    session, schoolTerm, next_term, name, studentClass, student_id, attendance,
    days_absent, studentSex, no_of_subjects, total_score, students_average,
    class_average, position_in_class, out_of, neatness, punctuality,
    sense_of_responsibility, teamwork, initiatiave, communication_skills,
    musical_skills, sports, craft, hardworking, teachers_remark, head_remark,
    ...subjects.flatMap(subject => [
      subject.subject,
      subject.test,
      subject.exam,
      subject.total,
      subject.grade,
      subject.remark,
    ])
  ]
    .map(field => (typeof field === 'string' ? field.toUpperCase() : field)) // Convert strings to uppercase
    .join(',');

  const filePath = path.join(__dirname, './data.csv');

  // Append row to the existing file
  fs.appendFile(filePath, `${row}\n`, (err) => {
    if (err) {
      console.error('Error writing to file:', err);
      return res.status(500).send('Error writing to file');
    }
    res.status(200).send('Data saved successfully');
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
